package com.contactportal.deloitte.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.contactportal.deloitte.model.Admin;
import com.contactportal.deloitte.model.User;

@Repository
public interface AdminDAO extends CrudRepository<Admin, String> {

	public List<Admin> findByAdminNameAndPassword(String adminName,String password);

	
}